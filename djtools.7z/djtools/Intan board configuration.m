% Intan board configuration
% as of 10.11.2016 
%
% necessary:
% soundcard trigger goes directly to Digital Input line 2
% 
% optional (but highly recommended)
% stimulus monitor goes through voltage divider to ADC Input line 1
% soundcard trigger goes directly to ADC Input line 2 (analog input)
% laser goes through voltage divider to ADC Input 3
% 
% for behavior, make sure you are recording channels 33,34,35, which show
% up as AUX1.continuous, AUX2.continuous, AUX3.continuous 



