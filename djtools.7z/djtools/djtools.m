%go to the djtools folder
djhome
cd djtools